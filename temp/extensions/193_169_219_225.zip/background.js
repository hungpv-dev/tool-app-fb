
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "193.169.219.225",
                    port: parseInt(50100)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "Sel61giaycom",
                    password: "W3r8OlP"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    