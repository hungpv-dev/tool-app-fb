
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.228.20.5",
                    port: parseInt(45774)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "SszaLu98T4t2h4S",
                    password: "703sNOIwSCHa1Wg"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    