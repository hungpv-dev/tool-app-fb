
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "62.164.255.151",
                    port: parseInt(49178)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "5KFr01yS823ZxMd",
                    password: "cDIeYuzHd9ip9ZC"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    