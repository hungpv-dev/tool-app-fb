
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "207.228.26.175",
                    port: parseInt(46122)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "E121jlygJOeQQmp",
                    password: "HODiAFkVcwOXvEN"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    