
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "77.83.20.90",
                    port: parseInt(63948)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {
        console.log("Proxy configuration set.");
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "3b2Ab5h82",
                    password: "XSVZBX41X"
                }
            };
        },
        { urls: ["<all_urls>"] },
        ["blocking"]
    );
    